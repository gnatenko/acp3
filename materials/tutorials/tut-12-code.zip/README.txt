SAT-solving Sudoku: session 12

Files in this archive:
- sudoku-exercises.ipynb: the guided student exercises.
- sudoku.ipynb: complete executable solutions and explanations.
- sudoku.py: the worked Python solution.

For installation and platform-specific setup, see the accompanying exercises PDF.
Install PySAT in your active virtual environment with:
    python -m pip install python-sat
For notebook work, also install JupyterLab with:
    python -m pip install jupyterlab ipykernel
Run the script with `python sudoku.py`, or open either notebook in JupyterLab.
The solution files are included for checking your work after attempting the exercises.
