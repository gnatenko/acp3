#!/usr/bin/env python3
"""Worked solution to Tutorial 12. Run: python sudoku.py.

Install python-sat in your active virtual environment first.
Exercises and notebook sections follow the same numbering.
"""

from itertools import combinations, product
from time import perf_counter
from pysat.formula import CNF
from pysat.solvers import Solver


def solve_cnf(clauses, name="g3"):
    """Return the true variable numbers, or None if the CNF is UNSAT."""
    with Solver(name=name, bootstrap_with=clauses) as solver:
        if not solver.solve():
            return None
        return {lit for lit in solver.get_model() if lit > 0}


def workshop_clauses():
    # 1: robotics, 2: painting, 3: reserve a kit.
    return [
        [1, 2],     # At least one workshop.
        [-1, -2],   # At most one workshop.
        [-1, 3],    # Robotics requires a kit.
    ]


def exactly_one(clauses, literals):
    """Require exactly one of the distinct literals; modify clauses in place."""
    literals = list(literals)
    clauses.append(literals)  # At least one; an empty clause is UNSAT.
    # Forbid each pair from being true together.
    for x, y in combinations(literals, 2):
        clauses.append([-x, -y])


puzzle = [
    "100007090",
    "030020008",
    "009600500",
    "005300900",
    "010080002",
    "600004000",
    "300000010",
    "040000007",
    "007000300",
]

def var(r, c, d):
    return 81 * r + 9 * c + d


def add_cells(clauses):
    for r in range(9):
        for c in range(9):
            exactly_one(clauses, [var(r, c, d) for d in range(1, 10)])


def add_rows(clauses):
    for r in range(9):
        for d in range(1, 10):
            exactly_one(clauses, [var(r, c, d) for c in range(9)])


def add_columns(clauses):
    for c in range(9):
        for d in range(1, 10):
            exactly_one(clauses, [var(r, c, d) for r in range(9)])


def add_blocks(clauses):
    for r0 in range(0, 9, 3):
        for c0 in range(0, 9, 3):
            for d in range(1, 10):
                candidates = [var(r, c, d)
                              for r in range(r0, r0 + 3)
                              for c in range(c0, c0 + 3)]
                exactly_one(clauses, candidates)


def add_clues(clauses, puzzle):
    for r in range(9):
        for c in range(9):
            d = int(puzzle[r][c])
            if d != 0:
                clauses.append([var(r, c, d)])


def build_sudoku_cnf(puzzle):
    if (len(puzzle) != 9 or
        any(not isinstance(row, str) or len(row) != 9 or
            any(ch not in "0123456789" for ch in row) for row in puzzle)):
        raise ValueError("Use nine strings of nine digits, with 0 for blanks")
    clauses = []
    add_cells(clauses)
    add_rows(clauses)
    add_columns(clauses)
    add_blocks(clauses)
    add_clues(clauses, puzzle)
    return CNF(from_clauses=clauses)


def decode(model):
    grid = []
    for r in range(9):
        row = []
        for c in range(9):
            choices = [d for d in range(1, 10) if var(r, c, d) in model]
            if len(choices) != 1:
                raise ValueError(f"Cell ({r}, {c}) has {len(choices)} digits")
            row.append(choices[0])
        grid.append(row)
    return grid


def valid_solution(grid, puzzle):
    """Check the original Sudoku rules independently of the CNF encoding."""
    if grid is None or len(grid) != 9 or any(len(row) != 9 for row in grid):
        return False
    digits = set(range(1, 10))
    rows_ok = all(set(row) == digits for row in grid)
    columns_ok = all({grid[r][c] for r in range(9)} == digits
                     for c in range(9))
    blocks_ok = all({grid[r][c]
                     for r in range(r0, r0 + 3)
                     for c in range(c0, c0 + 3)} == digits
                    for r0 in range(0, 9, 3)
                    for c0 in range(0, 9, 3))
    clues_ok = all(puzzle[r][c] == "0" or
                   grid[r][c] == int(puzzle[r][c])
                   for r in range(9) for c in range(9))
    return rows_ok and columns_ok and blocks_ok and clues_ok


def measure(cnf, name, phases=None):
    with Solver(name=name, bootstrap_with=cnf.clauses) as solver:
        if phases is not None:
            solver.set_phases(phases)
        start = perf_counter()
        answer = solver.solve()
        seconds = perf_counter() - start
        stats = solver.accum_stats()
        model = ({lit for lit in solver.get_model() if lit > 0}
                 if answer else None)
    return answer, seconds, stats, model


def main():
    print('\n1. Read a CNF')
    warmup = [[1, 2], [-1], [-2, 3]]
    model = solve_cnf(warmup)
    print("True variables:", model)
    print("With the extra clause:", solve_cnf(warmup + [[-3]]))

    print('\n2. Write three clauses')
    # Print truth values for robotics, painting, and reserving a kit.
    with Solver(name="g3", bootstrap_with=workshop_clauses()) as solver:
        for model in solver.enum_models():
            print(tuple(i in model for i in (1, 2, 3)))

    for values in product([False, True], repeat=3):
        units = [[i if value else -i]
                 for i, value in enumerate(values, start=1)]
        possible = solve_cnf(workshop_clauses() + units) is not None
        x, y, z = values
        expected = (x != y) and (not x or z)
        assert possible == expected, values
    print("All eight workshop assignments checked.")

    print('\n3. Build an exactly-one helper')
    for n in range(4):
        clauses = []
        exactly_one(clauses, range(1, n + 1))
        for values in product([False, True], repeat=n):
            units = [[i if value else -i]
                     for i, value in enumerate(values, start=1)]
            assert (solve_cnf(clauses + units) is not None) == (sum(values) == 1)
    print("Exactly-one checked for zero, one, two, and three candidates.")

    print('\n4. Encode Sudoku')
    assert {var(r, c, d) for r in range(9) for c in range(9)
            for d in range(1, 10)} == set(range(1, 730))
    for add_group in (add_cells, add_rows, add_columns, add_blocks):
        group = []
        add_group(group)
        assert len(group) == 81 * (1 + 36), add_group.__name__
    cnf = build_sudoku_cnf(puzzle)
    clue_count = sum(ch != "0" for row in puzzle for ch in row)
    assert cnf.nv == 729
    assert len(cnf.clauses) == 4 * 81 * 37 + clue_count
    print("Variables:", cnf.nv, "Clauses:", len(cnf.clauses))

    print('\n5. Solve and check the grid')
    model = solve_cnf(cnf.clauses)
    if model is None:
        print("UNSAT")
    else:
        solution = decode(model)
        for row in solution:
            print(" ".join(map(str, row)))
        assert valid_solution(solution, puzzle)
        broken = [row[:] for row in solution]
        broken[0][1] = broken[0][0]
        assert not valid_solution(broken, puzzle)
        print("The solution passes the Sudoku checks; the broken grid fails.")

    print('\n6. Explain an UNSAT answer')
    bad_puzzle = list(puzzle)
    bad_puzzle[0] = "110007090"
    bad_cnf = build_sudoku_cnf(bad_puzzle)
    assert solve_cnf(bad_cnf.clauses) is None
    print("Conflicting clues: UNSAT")

    print('\n7. Compare search choices (optional)')
    preferences = [var(r, c, 1) for r in range(9) for c in range(9)]
    for label, name, phases in (("MiniSat", "m22", None),
                                ("Glucose", "g3", None),
                                ("MiniSat with preferences", "m22", preferences)):
        answer, seconds, stats, model = measure(cnf, name, phases)
        assert answer and valid_solution(decode(model), puzzle)
        print(label, f"{seconds:.6f}s", stats)


if __name__ == "__main__":
    main()
